#ifndef _EPD_DRIVE_GPIO_H_
#define _EPD_DRIVE_GPIO_H_

/********************------------------------------------------------------------

Hardware interface

------------------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_gpio.h"
#include "main.h"
//GPIO config

#define EPD_CS_0	HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET)
#define EPD_CS_1	HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET)
#define isEPD_CS  HAL_GPIO_ReadPin(CS_GPIO_Port,CS_Pin)

#define EPD_RST_0	HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_RESET)
#define EPD_RST_1	HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_SET)
#define isEPD_RST  HAL_GPIO_ReadPin(RST_GPIO_Port,RST_Pin)

#define EPD_DC_0	HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_RESET)
#define EPD_DC_1	HAL_GPIO_WritePin(DC_GPIO_Port, DC_Pin, GPIO_PIN_SET)

#define isEPD_BUSY  HAL_GPIO_ReadPin(BUSY_GPIO_Port,BUSY_Pin)
#define EPD_BUSY_LEVEL 0




void SPI_Write(unsigned char value);
void driver_delay_xms(unsigned long xms);
#endif
