#include "EPD_drive_gpio.h"
#include "stm32f1xx_hal_spi.h"
#include "usart.h"
#include "spi.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>

/*********************************************


*********************************************/	
 void SPI_Write(unsigned char value)                                    
{     		
		HAL_SPI_Transmit(&hspi1, &value, 1, 500);
}

/*********************************************


*********************************************/	
void driver_delay_xms(unsigned long xms)	
{	
		HAL_Delay(xms);
}


