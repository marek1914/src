#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>

#define ADDR_FPGA_config      0x050
#define ADDR_FPGA_cfg_ctl     0x051
#define ADDR_FPGA_cfg_state   0x052
#define ADDR_FPGA_config_dat  0x053
#define ADDR_FPGA_rw_ctrl     0x054
#define ADDR_FPGA_rw_addr     0x055
#define ADDR_FPGA_wr_data     0x056
#define ADDR_FPGA_rd_data     0x057


void * map_base;


int main(int argc, char **argv)
{
	int fd;

    printf("start load fpga ...!\n");
	fd = open("/dev/mem", O_RDWR);
	if (fd < 0) {
		printf("open /dev/mem failed\n");
		return 0;
	}

	map_base = mmap(NULL, 0xff, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0x43c00000); 
	printf("map_base: %p\n", map_base);


    return 0;
}
