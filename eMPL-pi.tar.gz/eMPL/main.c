#include <stdio.h>
#include <stdint.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <linux/i2c-dev.h>
#include "inv_mpu.h"
#include "dmpmap.h"
#include "dmpKey.h"

// inv_mpu_dmp_motion_driver.h

int i2c_write(uint8_t dev, uint8_t reg, uint8_t len, uint8_t* data) 
{
	int8_t count = 0;
	uint8_t buf[128];
	int fd; 
	
	fd = open("/dev/i2c-1", O_RDWR);
	if (fd < 0) {
		printf("open fail\n");
		return -1; 
	}   
	
	if (ioctl(fd, I2C_SLAVE, dev) < 0) {
		printf("Failed to select device \n");
		return -1; 					    
	}   
	
	buf[0] = reg;
	memcpy(buf+1,data,len);
								    
	count = write(fd, buf, len+1);
    close(fd);

	return 0;
}

int8_t i2c_read(uint8_t dev, uint8_t reg, uint8_t len, uint8_t *data) {
    int8_t count = 0;

    int fd = open("/dev/i2c-1", O_RDWR);

    ioctl(fd, I2C_SLAVE, dev);
    write(fd, &reg, 1);
	read(fd, data, len);
    close(fd);
    return count;
}

int main(void)
{
	//struct int_param_s int_param;
	
	//int_param.cb = ;
	int ret;

	ret = mpu_init(NULL);
	printf("ret= %d\n", ret);	

	return 0;
}
